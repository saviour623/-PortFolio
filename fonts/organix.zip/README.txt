ENGLISH VERSION

This font is for personal use only.

Commercial use in any form without a valid license is strictly prohibited.

If you use this font for any commercial purpose without purchasing a license, you are violating the terms and will be fined $999.

To purchase a commercial license, please visit:
masyafistudio.com

For further inquiries, feel free to contact us at:
📧 masyafitim@gmail.com

Thank you for your understanding and support for independent creators.

BAHASA INDONESIA

Font ini hanya untuk penggunaan pribadi (personal use only).

Dilarang keras menggunakan font ini untuk keperluan komersial dalam bentuk apapun tanpa membeli lisensi.

Jika Anda menggunakan font ini untuk keperluan komersial tanpa lisensi, maka Anda dianggap telah melanggar aturan penggunaan dan akan dikenakan denda sebesar $999.

Untuk penggunaan komersial, silakan beli lisensi resmi melalui:
masyafistudio.com 

Atau hubungi kami untuk pertanyaan lebih lanjut melalui email:
📧 masyafitim@gmail.com

Terima kasih atas pengertiannya dan dukungannya untuk kreator lokal.