Hello

Thank for downloading this font.

By installing or using this font, you are agree to the Product Usage Agreement:
- This NOT FULL VERSION is ONLY for PERSONAL USE. NO COMMERCIAL USE ALLOWED!
- Please visit this link, if you need a commercial license (FULL VERSION) as below:

https://typebae.com/product/blanche

YOU ARE NOT ALLOWED TO:
- Sell and Redistribute
The items purchased are for your use only. you cannot sell and
redistribute it to any third party.
- More Use
Allowing more than one user to use item download/purchase from us.
- Convert
Converting Products into different format without written permission from us.
- Duplicate
You may not duplicate/copy the product to anyone without our permission.

WARNING!!!
If this free font (for Personal Use) is used for commercial purposes or violates the font usage terms (which is not allowed), a fine of $10,000 (ten thousand dollars) will be imposed.

Please send a short message with your question
hello@typebae.com

Please visit our store for more amazing fonts : 
https://typebae.com

Greetings,
Typebae Foundry